#!/bin/bash

if [ $# != 4 ]
  then
    echo ""
    echo "Usage: loadBlobs.sh Host, User, Password, Database"
    echo ""
    exit 1
fi

HOST=$1
USER=$2
PASSWORD=$3
DATABASE=$4

echo "Loading Protocols" 
../bin/loadProtocol.py $HOST $USER $PASSWORD $DATABASE
echo "Loading StudyImages" 
../bin/loadStudyImage.py $HOST $USER $PASSWORD $DATABASE
echo "Loading Study Files" 
../bin/loadStudyFile.py $HOST $USER $PASSWORD $DATABASE
