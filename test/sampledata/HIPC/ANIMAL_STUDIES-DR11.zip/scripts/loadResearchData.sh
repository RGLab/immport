#!/bin/bash

if [ $# != 4 ]
  then
    echo ""
    echo "Usage: loadLkData.sh Host, User, Password, Database"
    echo ""
    exit 1
fi

HOST=$1
USER=$2
PASSWORD=$3
DATABASE=$4

CMD="mysql --local_infile -h $HOST -u $USER -p$PASSWORD $DATABASE"

#############################################################################
# Program and Contract
#############################################################################
echo "Loading program"
$CMD < ../load/program.load
echo "Loading contract_grant"
$CMD < ../load/contract_grant.load
echo "Loading workspace"
$CMD < ../load/workspace.load

#############################################################################
# Protocol and Treatment
#############################################################################
echo "Loading protocol"
$CMD < ../load/protocol.load
echo "Loading treatment"
$CMD < ../load/treatment.load

#############################################################################
# Reagent
#############################################################################
echo "Loading reagent"
$CMD < ../load/reagent.load
echo "Loading reagent_set_2_reagent"
$CMD < ../load/reagent_set_2_reagent.load

# Removed 7/15/2014 - data moved to Reagent table.
#echo "Loading analyte"
#$CMD < ../load/analyte.load

#############################################################################
# Subject
#############################################################################
echo "Loading subject"
$CMD < ../load/subject.load
echo "Loading subject_2_protocol"
$CMD < ../load/subject_2_protocol.load
# Removed in September 2013
#echo "Loading subject_2_treatment"
#$CMD < ../load/subject_2_treatment.load

#############################################################################
# Study
#############################################################################
echo "Loading study"
$CMD < ../load/study.load
echo "Loading arm_or_cohort"
$CMD < ../load/arm_or_cohort.load
echo "Loading arm_2_subject"
$CMD < ../load/arm_2_subject.load
echo "Loading study_2_panel"
$CMD < ../load/study_2_panel.load
echo "Loading study_2_protocol"
$CMD < ../load/study_2_protocol.load
echo "Loading study_categorization"
$CMD < ../load/study_categorization.load
echo "Loading study_file"
$CMD < ../load/study_file.load
echo "Loading study_image"
$CMD < ../load/study_image.load
echo "Loading study_link"
$CMD < ../load/study_link.load
echo "Loading study_personnel"
$CMD < ../load/study_personnel.load
echo "Loading study_pubmed"
$CMD < ../load/study_pubmed.load
echo "Loading study_glossary"
$CMD < ../load/study_glossary.load
echo "Loading period"
$CMD < ../load/period.load
echo "Loading planned_visit"
$CMD < ../load/planned_visit.load
echo "Loading planned_visit_2_arm"
$CMD < ../load/planned_visit_2_arm.load
echo "Loading protocol_deviation"
$CMD < ../load/protocol_deviation.load
echo "Loading reference_range"
$CMD < ../load/reference_range.load
echo "Loading actual_visit"
$CMD < ../load/actual_visit.load

#############################################################################
# Biosample
#############################################################################
echo "Loading biosample"
$CMD < ../load/biosample.load
echo "Loading biosample_2_protocol"
$CMD < ../load/biosample_2_protocol.load
echo "Loading biosample_2_treatment"
$CMD < ../load/biosample_2_treatment.load

#############################################################################
# Experiment
#############################################################################
echo "Loading experiment"
$CMD < ../load/experiment.load
echo "Loading experiment_2_protocol"
$CMD < ../load/experiment_2_protocol.load

#############################################################################
# FileInfo
#############################################################################
echo "Loading file_info"
$CMD < ../load/file_info.load

#############################################################################
# Expsample
#############################################################################
echo "Loading expsample"
$CMD < ../load/expsample.load
echo "Loading expsample_2_file_info"
$CMD < ../load/expsample_2_file_info.load
echo "Loading expsample_2_reagent"
$CMD < ../load/expsample_2_reagent.load
echo "Loading expsample_2_treatment"
$CMD < ../load/expsample_2_treatment.load
echo "Loading biosample_2_expsample"
$CMD < ../load/biosample_2_expsample.load

echo "Loading control_sample"
$CMD < ../load/control_sample.load
echo "Loading control_sample_2_file_info"
$CMD < ../load/control_sample_2_file_info.load
echo "Loading standard_curve"
$CMD < ../load/standard_curve.load
echo "Loading standard_curve_2_file_info"
$CMD < ../load/standard_curve_2_file_info.load
echo "Loading expsample_mbaa_detail"
$CMD < ../load/expsample_mbaa_detail.load



#############################################################################
# FCS_ANNOTATION - need to wait until File_info, experiment and expsample
#############################################################################
# Removed 7/15/2014 - replaced by fcs_header table
#echo "Loading fcs_annotation"
#$CMD < ../load/fcs_annotation.load

#############################################################################
# Results
#############################################################################
echo "Loading elisa_result"
$CMD < ../load/elisa_result.load
echo "Loading elispot_result"
$CMD < ../load/elispot_result.load
echo "Loading hai_result"
$CMD < ../load/hai_result.load
echo "Loading pcr_result"
$CMD < ../load/pcr_result.load
echo "Loading neut_ab_titer_result"
$CMD < ../load/neut_ab_titer_result.load
echo "Loading fcs_analyzed_result"
$CMD < ../load/fcs_analyzed_result.load
echo "Loading hla_typing_result"
$CMD < ../load/hla_typing_result.load
echo "Loading kir_typing_result"
$CMD < ../load/kir_typing_result.load
echo "Loading mbaa_result"
$CMD < ../load/mbaa_result.load

#############################################################################
# HLA
#############################################################################
echo "Loading hla_allele_status"
$CMD < ../load/hla_allele_status.load
echo "Loading hla_typing_sys_feature"
$CMD < ../load/hla_typing_sys_feature.load
echo "Loading hla_typing_system"
$CMD < ../load/hla_typing_system.load

#############################################################################
# KIR
#############################################################################
echo "Loading kir_typing_system"
$CMD < ../load/kir_typing_system.load

#############################################################################
# Clinical
#############################################################################
echo "Loading adverse_event"
$CMD < ../load/adverse_event.load
echo "Loading assessment"
$CMD < ../load/assessment.load
echo "Loading inclusion_exclusion"
$CMD < ../load/inclusion_exclusion.load
echo "Loading lab_test"
$CMD < ../load/lab_test.load
echo "Loading reported_early_terimination"
$CMD < ../load/reported_early_termination.load
echo "Loading subject_measure_definition"
$CMD < ../load/subject_measure_definition.load
echo "Loading subject_measure_result"
$CMD < ../load/subject_measure_result.load
echo "Loading substance_merge"
$CMD < ../load/substance_merge.load

#############################################################################
# New for February 2014
#############################################################################
echo "Loading fcs_header"
$CMD < ../load/fcs_header.load
echo "Loading fcs_header_marker"
$CMD < ../load/fcs_header_marker.load

# Add in once this table is being populated 7/15/2014
#echo "Loading fcs_analyzed_result_marker"
#$CMD < ../load/fcs_analyzed_result_marker.load

echo "Loading expsample_public_repository"
$CMD < ../load/expsample_public_repository.load

# Add in once this table is being populated 7/15/2014
#echo "Loading reagent_2_fcs_marker"
#$CMD < ../load/reagent_2_fcs_marker.load
